# شاپ‌یار (ShopYar) | فاز ۳: ورود و ثبت‌نام

فروشگاه‌ساز موبایل‌محور برای فروشنده‌های اینستاگرامی. فرانت: React + TypeScript + Vite + Tailwind. بک‌اند: Supabase.

## تا اینجا چی کار می‌کنه
- ثبت‌نام با ایمیل و رمز (ساخت خودکار profile در دیتابیس)
- ورود، خروج، فراموشی رمز، تعیین رمز جدید از لینک ایمیل
- محافظ مسیرها: مهمان فقط صفحه‌های ورود، کاربر واردشده فقط پنل، نقش `admin` برای مسیرهای مدیریت
- پیام‌های خطای فارسی (هیچ خطای خامی به کاربر نشان داده نمی‌شود)
- صفحه‌های `/onboarding` و `/dashboard` فعلاً جای‌نگهدارند (فاز ۴ و ۱۰)

## ۱) تنظیمات Supabase
1. **Project Settings ← API:** مقدار Project URL و کلید عمومی (anon یا publishable) را بردار. کلید `secret` یا `service_role` را هرگز استفاده نکن.
2. **Authentication ← Sign In / Providers ← Email:** برای تست، گزینهٔ **Confirm email** را خاموش کن. در پروژهٔ جدید روشن است و ایمیل‌دهی پیش‌فرض Supabase فقط چند ایمیل در ساعت می‌فرستد. برای راه‌اندازی واقعی باید SMTP اختصاصی وصل کنی و آن را دوباره روشن کنی.
3. **Authentication ← URL Configuration:** بعد از Deploy، آدرس سایت را در **Site URL** بگذار و در **Redirect URLs** این‌ها را اضافه کن:
   `https://YOUR-SITE.netlify.app/**` و برای اجرای محلی `http://localhost:5173/**`
   (بدون این، لینک بازیابی رمز کار نمی‌کند.)

## ۲) اجرا روی کامپیوتر (اختیاری)
```bash
npm install
cp .env.example .env.local   # مقدارها را پر کن
npm run dev
```
`npm run build` فقط بیلد می‌کند. بررسی نوع‌ها جداست: `npm run typecheck` (تا خطای نوع جلوی Deploy را نگیرد).

## ۳) Deploy روی Netlify
1. کل پروژه را در یک مخزن GitHub بگذار (`.env` را هرگز commit نکن؛ در `.gitignore` هست).
2. Netlify ← **Add new site ← Import from Git**. تنظیمات از `netlify.toml` خوانده می‌شود (build: `npm run build`، publish: `dist`).
3. **Site configuration ← Environment variables:** این دو را اضافه کن:
   `VITE_SUPABASE_URL` و `VITE_SUPABASE_ANON_KEY`
4. Deploy بزن. اگر این دو متغیر نباشند، سایت صفحهٔ راهنما نشان می‌دهد.

## ۴) تست
1. `/signup` ← حساب بساز ← باید به `/onboarding` بروی (اگر Confirm email روشن باشد، پیام «ایمیلت را چک کن» می‌بینی).
2. خروج بزن، دوباره `/login` ← وارد شو.
3. `/forgot-password` ← لینک را از ایمیل باز کن ← رمز جدید بگذار.
4. در Supabase ← Table Editor ← `profiles`: باید ردیفی با `role = seller` ببینی.
5. بدون ورود، `/dashboard` را باز کن ← باید به `/login` بروی.

## ساختار
```
src/
  components/  ui/ (Button، Field، Toast...)  auth/ (AuthProvider، RequireAuth، GuestOnly)
  layouts/     AuthLayout
  pages/       auth/  onboarding/  seller/  HomePage  NotFoundPage
  services/    تنها جایی که با Supabase حرف می‌زند (auth، profile، shops)
  hooks/       useAuth، useMyShop، usePageTitle
  lib/         supabase، env، errors (پیام فارسی)، validation (zod)
  types/       database
supabase/      فاز ۲: migrationها و seed
```

## Mock یا واقعی
همه‌چیز در این فاز واقعی است. هیچ بخش Mock ندارد.

## نکته‌های امنیتی
- فقط کلید عمومی (anon/publishable) در فرانت است.
- CSP و هدرهای امنیتی در `netlify.toml` فعال است. اگر دامنهٔ اختصاصی برای Supabase گرفتی، آن را به `connect-src` و `img-src` اضافه کن.
- پیام «ایمیل ثبت نشده» برای بازیابی رمز عمداً نشان داده نمی‌شود (جلوگیری از حدس‌زدن ایمیل‌ها).
